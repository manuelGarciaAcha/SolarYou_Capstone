#include "startup_stubs.h"
