# ble-jennifer

The current setup, configuration, team handoff and validation notes are in [README.md](README.md).
